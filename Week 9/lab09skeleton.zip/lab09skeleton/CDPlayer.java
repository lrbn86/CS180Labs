import java.util.ArrayList;

/**
 * Class CDPlayer
 */
public class CDPlayer extends MusicPlayer {

    private int deviceID;
    private int thisTrack;

    /**
     * Constructor for CD-Player
     */
    public CDPlayer(int id) {

    }

    /**
     * Over-ride Method: turnOn
     */
    public void turnOn() {

    }

    /**
     * Over-ride Method: turnOff
     */
    public void turnOff() {

    }

    /**
     * Method to play next track in the playlist by
     * printing it to stdout and changing current
     */
    public void nextTrack() {

    }

    /**
     * Method to play previous track in the playlist by
     * printing it to stdout and changing current
     */
    public void previousTrack() {

    }

    /**
     * Method to play current track
     */
    public void play() {

    }

}
